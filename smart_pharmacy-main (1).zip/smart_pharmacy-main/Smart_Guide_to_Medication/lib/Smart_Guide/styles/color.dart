import 'package:flutter/material.dart';


const whiteColor1 = Color.fromARGB(255, 252, 252, 241);
Color whiteColor2 = Colors.black.withOpacity(0.05);

const blackColor1 = Color.fromARGB(255, 26, 26, 26);
const blackColor2 = Color.fromARGB(255, 34, 34, 34);
