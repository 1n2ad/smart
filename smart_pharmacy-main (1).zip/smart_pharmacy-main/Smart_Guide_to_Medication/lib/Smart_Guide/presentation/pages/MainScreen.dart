import 'package:flutter/material.dart';
class MainScreen extends StatelessWidget {
  const MainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const MainScreen_state();
  }
}
class MainScreen_state extends StatefulWidget {
  const MainScreen_state({super.key});

  @override
  State<MainScreen_state> createState() => _MainScreen_stateState();
}

class _MainScreen_stateState extends State<MainScreen_state> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}

