import 'package:flutter/cupertino.dart';
import 'color.dart';

const TextStyle bntText = TextStyle(
  fontSize: 13,
  color: black,
  fontWeight: FontWeight.w500,
  fontFamily: 'osamh_light'
);
