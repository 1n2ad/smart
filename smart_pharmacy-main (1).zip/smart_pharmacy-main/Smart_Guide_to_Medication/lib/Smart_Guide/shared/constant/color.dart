import 'package:flutter/cupertino.dart';

const Color black = Color(0xFF191555);
const Color white = Color(0xFFFFFFFF);
const Color bgColor = Color(0xFF2196F3);
const Color selectColor = Color(0xFFFF0000);
