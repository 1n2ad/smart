package com.smart_guide_to_medication.smart_guide_to_medication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
